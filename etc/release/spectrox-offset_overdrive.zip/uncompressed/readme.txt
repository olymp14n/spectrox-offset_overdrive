Contains uncompressed versions of the intro.
Mainly to avoid false positive alarms by virus scanners with the compressed version.

- spectrox-offset_overdrive-uncompressed_1920x1080.exe
  Uncompressed version of the intro. Changes resolution to 1920x1080. Recommended version.

- spectrox-offset_overdrive-uncompressed_1920x1080_scanlines.exe
  Uncompressed version of the intro. Changes resolution to 1920x1080 with added scanlines.

- spectrox-offset_overdrive-uncompressed_desktop_resolution.exe
  Uncompressed version of the intro. Does not change desktop resolution.

- spectrox-offset_overdrive-uncompressed_windowed.exe
  Uncompressed version of the intro in a window.
